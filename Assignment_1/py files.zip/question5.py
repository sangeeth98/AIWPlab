import math
radius = float(input("Enter Radius r = "))
pi = math.pi
diameter = 2*radius
circumference =  2*pi*radius
area = pi*radius*radius
print("Diameter = %.2f\nCircumference = %.2f\nArea = %.2f"%(diameter,circumference,area))
