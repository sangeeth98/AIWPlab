for i in range(5):
    print('hello %d\a' % i)
