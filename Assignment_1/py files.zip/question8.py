num = int(input("Enter a size: "))
for i in range(num):
    print('+'*(i+1))