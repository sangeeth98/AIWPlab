# Using escape character \b
print("Apple\b")
print("Apple\b ")
print("\bApple")
print("Apple\b is good for health")
print("He is a good man")
print("He is a good\b\b\b\bman")

"""
\b represents an ASCII backspace (BS) character
It works like a normal backspace in keyboard
It won't eliminates a characted before its position 
until there is another character after it (Shown
in the second example)
"""